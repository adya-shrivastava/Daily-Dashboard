export const apiKey = "kqD3NtfpL6AmOsAP1rQVmHacZy0aGyioSqwPwQ1gfhqjqMWx3adhwyTBt5L9Ne7S";
export const cors_api_url = 'https://protected-ocean-85956.herokuapp.com/';

export const weatherApi = '0827e2a24e5b696e8570714f34824e50';